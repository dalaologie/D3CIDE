const express = require('express');
const cors = require('cors');
const { Configuration, OpenAIApi } = require('openai');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const openai = new OpenAIApi(new Configuration({
  apiKey: process.env.OPENAI_API_KEY
}));

app.post('/api/d3cide', async (req, res) => {
  const question = req.body.question;
  const prompt = `Tu es D3CIDE, l’oracle Dalaologique. Réponds avec puissance, mystère et stratégie à : "${question}"`;

  try {
    const completion = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.85,
      max_tokens: 100
    });

    const result = completion.data.choices[0].message.content;
    res.json({ response: result });
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500).json({ error: "Erreur dans la réponse GPT" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`D3CIDE API running on port ${PORT}`);
});
